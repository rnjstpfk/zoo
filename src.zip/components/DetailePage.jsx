import React, { useMemo, useState } from "react";
import "../styles/product-detail.scss";


import p1 from "../assets/DetailePage/p1.jpg";
import p2 from "../assets/DetailePage/p2.jpg";
import p3 from "../assets/DetailePage/p3.jpg";
import p4 from "../assets/DetailePage/p4.jpg";
import p5 from "../assets/DetailePage/p5.jpg";
import p6 from "../assets/DetailePage/p6.jpg";

const MOCK = {
    title: "Product Name",
    price: 69000,
    likeCount: 741,
    couponBanner: "첫 구매 20% 쿠폰 받으러 가기",
    pointMax: "2,500원 최대적립",
    pointReview: "후기 적립",
    sizes: ["S", "M", "L"],
    images: [p1, p2, p3, p4, p5, p6],
};

const KRW = (n) => n.toLocaleString("ko-KR");

/** Breadcrumbs (숫자 대신 > 구분자) */
function Breadcrumbs() {
    const paths = ["카테고리", "세부 카테고리", "Content name"];
    return (
        <nav className="pd-breadcrumbs is-compact" aria-label="breadcrumbs">
            <ul>
                {paths.map((p, i) => (
                    <li key={i} className={i === paths.length - 1 ? "current" : ""}>
                        {i < paths.length - 1 ? <a href="#">{p}</a> : p}
                        {i < paths.length - 1 && <span className="sep">{">"}</span>}
                    </li>
                ))}
            </ul>
        </nav>
    );
}

function Gallery({ images }) {
    const [idx, setIdx] = useState(0);
    const next = () => setIdx((p) => (p + 1) % images.length);
    const prev = () => setIdx((p) => (p - 1 + images.length) % images.length);
    return (
        <div className="pd-gallery">
            <aside className="thumbs">
                {images.map((src, i) => (
                    <button key={i} onClick={() => setIdx(i)} className={`thumb ${i === idx ? "active" : ""}`}>
                        <img src={src} alt={`thumb-${i}`} />
                    </button>
                ))}
            </aside>
            <div className="main">
                <div className="img-wrap">
                    <img src={images[idx]} alt="product" />
                    <button className="nav prev" onClick={prev} aria-label="prev">‹</button>
                    <button className="nav next" onClick={next} aria-label="next">›</button>
                </div>

            </div>
        </div>
    );
}

/** 구매박스 (Breadcrumbs는 여기만 표시) */
function PurchaseBoxLite({
    title = MOCK.title,
    price = MOCK.price,
    likeCount = MOCK.likeCount,
    couponBanner = MOCK.couponBanner,
    pointMax = MOCK.pointMax,
    pointReview = MOCK.pointReview,
    sizes = MOCK.sizes,
}) {
    const [size, setSize] = useState("");
    const total = useMemo(() => price, [price]);

    return (
        <aside className="pd-buybox lite">
            {/* ✅ 이제 Breadcrumbs는 여기만 */}
            <Breadcrumbs />

            <h1 className="p-title">{title}</h1>
            <div className="p-price">₩{KRW(price)}</div>

            {/* 파란 쿠폰 배너 */}
            <button className="row banner blue" type="button">
                <span>{couponBanner}</span>
                <span className="chev">›</span>
            </button>

            {/* 적립 2줄 */}
            <div className="row benefit-stack">
                <div className="note white">{pointMax}</div>
                <div className="note gray">{pointReview}</div>
            </div>

            {/* 사이즈 */}
            <label className="row select">
                <span className="label">사이즈</span>
                <select value={size} onChange={(e) => setSize(e.target.value)}>
                    <option value="" disabled>사이즈</option>
                    {sizes.map((s) => (<option key={s} value={s}>{s}</option>))}
                </select>
                <span className="chev">▾</span>
            </label>

            {/* 버튼들 */}
            <div className="row action">
                <button className="like" type="button">♡ <span>{likeCount}</span></button>
                <button className="cart" type="button">장바구니</button>
                <button className="buy" type="button">결제하기</button>
            </div>

            {/* 결제혜택 */}
            <div className="post-actions">
                <div className="divider" />
                <div className="benefit-head">
                    <div className="title">결제혜택</div>
                    <a href="#" className="more">전체보기</a>
                </div>
                <ul className="benefit-list">
                    <li>카드할인 안내</li>
                    <li>5만원 이상 무료배송<br /><small>(일부 상품 및 도서 산간 지역 제외)</small></li>
                    <li>도착 예정 날짜 안내 · 도착 확률 99%<br />결제 3일 이내 출고 · CJ대한통운</li>
                </ul>
            </div>

            <div className="row total">총 금액 <strong>₩{KRW(total)}</strong></div>
        </aside>
    );
}

export default function ProductDetailPage() {
    return (
        <main className="product-detail">
            <div className="container">
                {/* 상단 Breadcrumbs 제거됨 */}
                <div className="hero">
                    <Gallery images={MOCK.images} />
                    <PurchaseBoxLite />
                </div>
            </div>
        </main>
    );
}
